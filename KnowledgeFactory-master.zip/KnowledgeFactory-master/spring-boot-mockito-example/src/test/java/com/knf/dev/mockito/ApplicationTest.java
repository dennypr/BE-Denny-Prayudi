package com.knf.dev.mockito;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApplicationTest {

	@Test
	public void main() {
		Application.main(new String[] {});
	}

}