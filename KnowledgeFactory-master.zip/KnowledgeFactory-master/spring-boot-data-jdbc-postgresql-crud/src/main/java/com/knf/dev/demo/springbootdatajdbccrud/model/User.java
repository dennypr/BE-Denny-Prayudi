package com.knf.dev.demo.springbootdatajdbccrud.model;

public record User
(Long id, 
	String firstName, 
		String lastName,
		  String email) {
}

