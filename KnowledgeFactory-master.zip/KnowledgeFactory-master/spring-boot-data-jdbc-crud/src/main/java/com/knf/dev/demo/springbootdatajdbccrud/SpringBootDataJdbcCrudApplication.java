package com.knf.dev.demo.springbootdatajdbccrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDataJdbcCrudApplication {

	public static void main(String[] args) {
		SpringApplication.
		 run(SpringBootDataJdbcCrudApplication.class, args);
	}

}
