package com.knf.dev.demo.springbootdatajdbccrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataJdbcCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
