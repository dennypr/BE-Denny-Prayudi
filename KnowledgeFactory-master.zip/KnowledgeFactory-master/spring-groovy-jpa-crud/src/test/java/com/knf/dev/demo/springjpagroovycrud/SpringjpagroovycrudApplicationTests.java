package com.knf.dev.demo.springjpagroovycrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringjpagroovycrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
