package com.knf.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebfluxVideoStreamingExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebfluxVideoStreamingExampleApplication.class, args);
	}

}
