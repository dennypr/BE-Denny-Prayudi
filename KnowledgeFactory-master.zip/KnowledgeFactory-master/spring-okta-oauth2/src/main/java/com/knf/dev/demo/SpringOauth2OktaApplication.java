package com.knf.dev.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOauth2OktaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringOauth2OktaApplication.class, args);
	}

}
