package com.knf.dev.demo.springoauth2github;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springoauth2GithubApplicationTests {

	@Test
	void contextLoads() {
	}

}
