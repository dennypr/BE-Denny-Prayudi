package com.knf.dev.demo.springoauth2github;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springoauth2GithubApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springoauth2GithubApplication.class, args);
	}

}
