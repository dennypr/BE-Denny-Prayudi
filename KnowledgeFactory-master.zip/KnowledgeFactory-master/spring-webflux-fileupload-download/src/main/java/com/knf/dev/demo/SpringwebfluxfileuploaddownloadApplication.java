package com.knf.dev.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwebfluxfileuploaddownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwebfluxfileuploaddownloadApplication.class, args);
	}

}
