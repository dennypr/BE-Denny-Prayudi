package com.knf.dev.demo.springbootpostgresqlcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPostgresqlCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
