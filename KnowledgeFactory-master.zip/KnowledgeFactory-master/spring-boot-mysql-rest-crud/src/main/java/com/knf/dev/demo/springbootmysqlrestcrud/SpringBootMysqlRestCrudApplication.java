package com.knf.dev.demo.springbootmysqlrestcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMysqlRestCrudApplication {

	public static void main(String[] args) {
		SpringApplication.
		   run(SpringBootMysqlRestCrudApplication.class, args);
	}

}
