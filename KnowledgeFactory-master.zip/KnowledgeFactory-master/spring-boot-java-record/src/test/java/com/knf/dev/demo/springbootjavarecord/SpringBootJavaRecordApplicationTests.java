package com.knf.dev.demo.springbootjavarecord;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJavaRecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
