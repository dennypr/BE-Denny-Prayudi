package com.knf.dev.demo.springbootjavarecord.dto;

public record 
User(Long id, String firstName, 
		String lastName, String email) {
}
