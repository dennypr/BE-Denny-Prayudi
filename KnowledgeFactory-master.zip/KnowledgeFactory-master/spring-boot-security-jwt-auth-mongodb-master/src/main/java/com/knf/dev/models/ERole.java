package com.knf.dev.models;

public enum ERole {
	ROLE_EMPLOYEE, ROLE_ADMIN
}
