More Info - https://www.knowledgefactory.net/2022/08/generate-qr-code-in-spring-boot-thymeleaf-application-with-zxing-example.html
