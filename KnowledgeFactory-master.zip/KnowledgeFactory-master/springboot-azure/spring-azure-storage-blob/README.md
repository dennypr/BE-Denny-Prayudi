# Upload, Download, And Delete File To Azure Blob Storage With Spring Boot

<img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj98MhjC-0g2PvZMW2boHM7049LC_w2r7bVe8MjNGP56P_1P3a-PcHS8tcoqGBUX7XVBW8G5cOBKjHI8QYlEJ_TcxXSymGZddejcDYrsaglTO1di7NoDnnukH9GQOX7Fi9_VYnhqevbKEEOofzg1-Nzg8Jl_gN4aHbANjA1Ode5vpRgWtZkxIva9DTtPQ/w640-h274/upload-download-delete-image-azure-blob.png" >

# Local setup

Step 1: Download or clone the source code from GitHub to the local machine

Step 2:  ```mvn clean install```

Step 3:  ```mvn spring-boot:run```

More Info - https://www.knowledgefactory.net/2022/07/upload-download-and-delete-file-to-azure-blob-storage-with-spring-boot.html




