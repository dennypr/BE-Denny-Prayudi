package com.knf.dev.demo.springdatajdbcazurepostgrescrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJdbcAzurePostgresCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJdbcAzurePostgresCrudApplication.class, args);
	}

}
