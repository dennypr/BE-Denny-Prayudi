# Build REST CRUD APIs with Spring Boot, Azure Cosmos DB  and Azure Cosmos DB SQL API


# Local setup

Step 1: Download or clone the source code from GitHub to the local machine

Step 2:  ```mvn clean install```

Step 3:  ```mvn spring-boot:run```

More Info - https://www.knowledgefactory.net/2022/07/build-rest-crud-apis-with-spring-boot-azure-cosmos-db-and-azure-cosmos-db-sql-api.html




