# Building Reactive REST CRUD APIs with Spring Boot, Spring WebFlux, Azure Cosmos DB and Azure Cosmos DB SQL API


# Local setup

Step 1: Download or clone the source code from GitHub to the local machine

Step 2:  ```mvn clean install```

Step 3:  ```mvn spring-boot:run```

More Info - https://www.knowledgefactory.net/2022/07/building-reactive-rest-crud-apis-with-spring-boot-spring-webflux-azure-cosmos-db-and-azure-cosmos-db-sql-api.html




