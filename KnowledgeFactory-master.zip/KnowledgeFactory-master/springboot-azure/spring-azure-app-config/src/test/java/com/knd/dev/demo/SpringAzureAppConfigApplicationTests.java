package com.knd.dev.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAzureAppConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
