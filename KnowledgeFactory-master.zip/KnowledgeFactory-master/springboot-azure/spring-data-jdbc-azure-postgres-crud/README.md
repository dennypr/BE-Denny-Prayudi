# Local setup

Step 1: Download or clone the source code from GitHub to the local machine

Step 2:  ```mvn clean install```

Step 3:  ```mvn spring-boot:run```a
