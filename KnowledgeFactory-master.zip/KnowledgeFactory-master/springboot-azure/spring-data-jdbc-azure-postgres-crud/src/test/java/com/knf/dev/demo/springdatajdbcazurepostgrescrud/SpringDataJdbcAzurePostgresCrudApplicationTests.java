package com.knf.dev.demo.springdatajdbcazurepostgrescrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJdbcAzurePostgresCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
