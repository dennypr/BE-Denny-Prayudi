package com.knf.dev.demo.springwebfluxsimplecrudexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwebfluxsimplecrudexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwebfluxsimplecrudexampleApplication.class, args);
	}
}
